"""Independent answer check for problem14.pg.

Derived from the problem statement, not from the Perl.
"""

from math import ceil, sqrt


def expected(p):
    N, mean, sd, share = p["N"], p["mean"], p["sd"], p["share"]
    inside = int(share * N + 0.5)
    return {
        "AnSwEr0001": mean - 2 * sd,
        "AnSwEr0002": N - inside,
        "AnSwEr0003": inside / N,
        "AnSwEr0004": inside / N - 0.75,
    }
