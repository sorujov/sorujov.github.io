"""Independent answer check for problem13.pg.

Derived from the problem statement, not from the Perl.
"""

from math import ceil, sqrt


def expected(p):
    mean, sd, want = p["mean"], p["sd"], p["want"]
    k = sqrt(1 / (1 - want))                      # invert 1 - 1/k^2 = want
    return {
        "AnSwEr0001": k,
        "AnSwEr0002": mean - k * sd,
        "AnSwEr0003": mean + k * sd,
        "AnSwEr0004": 2 * k * sd,
    }
