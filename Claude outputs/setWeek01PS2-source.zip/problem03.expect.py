"""Independent answer check for problem03.pg.

Derived from the problem statement, not from the Perl.
"""

from math import ceil, sqrt


def expected(p):
    c = [p["c%d" % i] for i in range(1, 8)]
    n = 7
    mean = sum(c) / n
    median = sorted(c)[3]
    return {"AnSwEr0001": mean, "AnSwEr0002": median, "AnSwEr0003": mean - median}
