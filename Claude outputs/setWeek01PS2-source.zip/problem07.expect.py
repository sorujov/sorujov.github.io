"""Independent answer check for problem07.pg.

Derived from the problem statement, not from the Perl.
"""

from math import ceil, sqrt


def expected(p):
    N = p["N"]
    tcheb = (1 - 1 / 4) * N                       # k = 2
    emp = 0.95 * N
    return {"AnSwEr0001": tcheb, "AnSwEr0002": emp, "AnSwEr0003": emp - tcheb}
