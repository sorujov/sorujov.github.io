"""Independent answer check for problem15.pg.

Derived from the problem statement, not from the Perl.
"""

from math import ceil, sqrt


def expected(p):
    n1, n2, m1, m2 = p["n1"], p["n2"], p["m1"], p["m2"]
    pooled = (n1 * m1 + n2 * m2) / (n1 + n2)
    naive = (m1 + m2) / 2
    return {
        "AnSwEr0001": n1 * m1,
        "AnSwEr0002": pooled,
        "AnSwEr0003": naive,
        "AnSwEr0004": pooled - naive,
    }
