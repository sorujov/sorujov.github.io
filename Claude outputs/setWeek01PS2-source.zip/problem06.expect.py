"""Independent answer check for problem06.pg.

Derived from the problem statement, not from the Perl.
"""

from math import ceil, sqrt


def expected(p):
    mean, sd, N = p["mean"], p["sd"], p["N"]
    return {
        "AnSwEr0001": mean + 2 * sd,
        "AnSwEr0002": 1 - 0.95,                   # both tails
        "AnSwEr0003": (1 - 0.95) / 2,             # one tail, by symmetry
        "AnSwEr0004": ((1 - 0.95) / 2) * N,
    }
