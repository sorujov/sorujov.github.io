"""Independent answer check for problem12.pg.

Derived from the problem statement, not from the Perl.
"""

from math import ceil, sqrt


def expected(p):
    # PG reports some draws back as strings, so coerce before any arithmetic.
    start, w = float(p["start"]), float(p["w"])
    f = [float(p["f%d" % i]) for i in range(1, 5)]
    m = [start + w / 2 + i * w for i in range(4)]
    n = sum(f)
    mean = sum(fi * mi for fi, mi in zip(f, m)) / n
    var = sum(fi * (mi - mean) ** 2 for fi, mi in zip(f, m)) / (n - 1)
    return {
        "AnSwEr0001": n,
        "AnSwEr0002": mean,
        "AnSwEr0003": var,
        "AnSwEr0004": sqrt(var),
    }
