"""Independent answer check for problem11.pg.

Derived from the problem statement, not from the Perl.
"""

from math import ceil, sqrt


def expected(p):
    mean, sd, fee, rate = p["mean"], p["sd"], p["fee"], p["rate"]
    # z = (y - fee)/rate : the mean follows the data, the sd ignores the shift
    return {
        "AnSwEr0001": mean - fee,
        "AnSwEr0002": sd,
        "AnSwEr0003": (mean - fee) / rate,
        "AnSwEr0004": sd / rate,
    }
