"""Independent answer check for problem18.pg.

Derived from the problem statement, not from the Perl.
"""

from math import ceil, sqrt


def expected(p):
    N = p["N"]
    return {"AnSwEr0001": 0.68 * N, "AnSwEr0002": 0.95 * N}
