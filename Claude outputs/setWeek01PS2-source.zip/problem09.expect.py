"""Independent answer check for problem09.pg.

Derived from the problem statement, not from the Perl.
"""

from math import ceil, sqrt


def expected(p):
    mean, var = p["mean"], p["var"]
    sd = sqrt(var)
    return {"AnSwEr0001": sd, "AnSwEr0002": mean - 2 * sd, "AnSwEr0003": mean + 2 * sd}
