"""Independent answer check for problem08.pg.

Derived from the problem statement, not from the Perl.
"""

from math import ceil, sqrt


def expected(p):
    y = [p["y%d" % i] for i in range(1, 11)]
    n = 10
    mean = sum(y) / n
    # defining formula, not the computing formula the problem hands the student
    var = sum((v - mean) ** 2 for v in y) / (n - 1)
    return {"AnSwEr0001": mean, "AnSwEr0002": var, "AnSwEr0003": sqrt(var)}
