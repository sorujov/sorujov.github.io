"""Independent answer check for problem20.pg.

Derived from the problem statement, not from the Perl.
"""

from math import ceil, sqrt


def expected(p):
    r = [p["r%d" % i] for i in range(1, 13)]
    n = 12
    mean = sum(r) / n
    var = sum((v - mean) ** 2 for v in r) / (n - 1)
    sd = sqrt(var)
    lo, hi = mean - 2 * sd, mean + 2 * sd
    inside = sum(1 for v in r if lo <= v <= hi)
    return {
        "AnSwEr0001": mean,
        "AnSwEr0002": sd,
        "AnSwEr0003": (max(r) - min(r)) / 4,
        "AnSwEr0004": lo,
        "AnSwEr0005": inside / n,
    }
