"""Independent answer check for problem05.pg.

Derived from the problem statement, not from the Perl.
"""

from math import ceil, sqrt


def expected(p):
    mean, sd, N = p["mean"], p["sd"], p["N"]
    return {
        "AnSwEr0001": mean - sd,
        "AnSwEr0002": mean + sd,
        "AnSwEr0003": mean - 2 * sd,
        "AnSwEr0004": 0.95 * N,
    }
