"""Independent answer check for problem10.pg.

Derived from the problem statement, not from the Perl.
"""

from math import ceil, sqrt


def expected(p):
    d = [p["d%d" % i] for i in range(1, 6)]
    d6 = -sum(d)                                  # deviations sum to zero
    ss = sum(v * v for v in d) + d6 * d6
    var = ss / 5                                  # n = 6
    return {
        "AnSwEr0001": d6,
        "AnSwEr0002": var,
        "AnSwEr0003": sqrt(var),
        "AnSwEr0004": ss / 6,
    }
