"""Independent answer check for problem03.pg.

Derived from the statement of Tchebysheff's theorem, not from the Perl.
"""


def expected(p):
    mean, sd, k, N = p["mean"], p["sd"], p["k"], p["N"]
    # At least 1 - 1/k^2 of the measurements lie within k standard deviations.
    bound = (k * k - 1) / (k * k)      # written as one fraction, not 1 - 1/k**2
    return {
        "AnSwEr0001": bound,
        "AnSwEr0002": mean - k * sd,
        "AnSwEr0003": mean + k * sd,
        "AnSwEr0004": bound * N,
    }
