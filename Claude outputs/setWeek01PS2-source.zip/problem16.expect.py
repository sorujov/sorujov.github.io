"""Independent answer check for problem16.pg.

Derived from the problem statement, not from the Perl.
"""

from math import ceil, sqrt


def expected(p):
    mu, sigma, k = p["mu"], p["sigma"], p["k"]
    # empirical rule tails: 16% beyond one sd, 2.5% beyond two
    pct = 16 if k == 1 else 2.5
    return {"AnSwEr0001": mu + k * sigma, "AnSwEr0002": pct}
